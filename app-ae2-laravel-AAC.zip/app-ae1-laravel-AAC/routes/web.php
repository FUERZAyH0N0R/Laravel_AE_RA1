<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LibroController_AAC;

Route::get('/', function () {
    return 'Bienvenido a mi primera aplicación Laravel';
});


Route::get('/libros', [LibroController_AAC::class, 'index']);