@extends('layouts.app')

@section('contenido')

@if($libros->count() > 0)

<TABLE border="1">
    <tr>
    <th>Título</th>
    <th>Autor</th>
    <th>Año</th>
    </tr>

    @foreach($libros as $libro)
    <tr>
    <td>{{$libro->titulo}}</td>
    <td>{{$libro->autor}}</td>
    <td>{{$libro->anio_publicacion}}</td>
    </tr>
    @endforeach

    </table>

    @else

    <p>No exiten libros registrados.</p>

    @endif

    @endsection