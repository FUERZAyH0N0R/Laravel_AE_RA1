<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <TITLE>Catálogo de Libros</TITLE>
</head>
<body>

    <h1>Catálogo de Libros</h1>

    @yield('contenido')

 </body>
 </html>