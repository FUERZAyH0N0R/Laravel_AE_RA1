<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Libro;

class LibroController_AAC extends Controller
{
    public function index()
    {

        $libros = Libro::all();
    
        return view('libros.index', compact ('libros'));

    }
}
