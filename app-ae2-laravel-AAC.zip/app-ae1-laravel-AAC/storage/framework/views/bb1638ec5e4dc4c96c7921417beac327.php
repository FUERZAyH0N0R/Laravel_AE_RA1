<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <TITLE>Catálogo de Libros</TITLE>
</head>
<body>

    <h1>Catálogo de Libros</h1>

    <?php echo $__env->yieldContent('contenido'); ?>

 </body>
 </html><?php /**PATH C:\xampp\htdocs\app-ae1-laravel-AAC\resources\views/layouts/app.blade.php ENDPATH**/ ?>