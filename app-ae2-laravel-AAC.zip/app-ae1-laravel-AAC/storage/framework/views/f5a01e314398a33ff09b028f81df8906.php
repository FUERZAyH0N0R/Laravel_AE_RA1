

<?php $__env->startSection('contenido'); ?>

<?php if($libros->count() > 0): ?>

<TABLE border="1">
    <tr>
    <th>Título</th>
    <th>Autor</th>
    <th>Año</th>
    </tr>

    <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($libro->titulo); ?></td>
    <td><?php echo e($libro->autor); ?></td>
    <td><?php echo e($libro->anio_publicacion); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

    <?php else: ?>

    <p>No exiten libros registrados.</p>

    <?php endif; ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\app-ae1-laravel-AAC\resources\views/libros/index.blade.php ENDPATH**/ ?>